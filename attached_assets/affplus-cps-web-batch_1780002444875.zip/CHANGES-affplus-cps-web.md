# Affplus CPS (Web) — change bundle (post-audit hardening)

Six files: two new, four edits. The mobile path is unchanged.

## Audit fixes applied
- SSRF (was critical): the preview-link follow now uses an SSRF-safe follower
  (`safeFollow`) that rejects non-http(s) schemes and resolves+blocks private,
  loopback, link-local, CGNAT, and reserved addresses at every redirect hop,
  including DNS-resolved internal hosts. Proven at runtime against the cloud
  metadata IP, loopback, private ranges, IPv6 loopback, and `localhost`.
  `classifier.resolveRedirects` was re-privatized (no longer reused).
- Name mangling (was high): `normalizeWebOffer` replaces the mobile cleaner on
  the web path. "MoneyMutual.com US CPS Non Incent" now yields advertiser_name
  "MoneyMutual.com" and search query "MoneyMutual.com" (was "MoneyMutual.com
  Non"). "Godlike.Host [CPS] WW" yields "Godlike.Host".
- Prompt injection (was high): the offer name, category, and description are now
  fenced as untrusted data in the search prompt with an explicit do-not-follow
  instruction.
- Client hardening (was medium): the Anthropic client uses bounded retries (1)
  and a 60s per-request timeout instead of the SDK defaults of 2 / 10 min.
- URL hygiene (was medium): destinations are stripped of tracking query and
  fragment, dead pages (HTTP >= 400) are dropped, and the follow uses a desktop
  User-Agent.

## First-run diagnostics added (for the two items unverifiable offline)
- Geo binding: per-country geo-match tally, with a loud warn if no returned
  offer matches the requested country (the affplus Desktop geos filter is
  unverified and recon saw params normalized away).
- Detail parse: a debug line per offer showing whether category, description,
  and the preview link were actually extracted from the real affplus HTML.
- Yield ceiling: a warn when the name-search budget is fully consumed with
  offers still unresolved, plus an empty-CSV warn pointing at the warnings above.

## Gates (verified)
- typecheck: 0 errors.
- self-tests: webPolicy 41/41, webResolver 45/45 (was 20), storeResolver 10/10,
  nameCleaner 18/18.

## New env knobs (all optional)
- `AFFPLUS_WEB_FOLLOW_MAX_HOPS` (default 5)
- `AFFPLUS_WEB_SEARCH_MAX_RETRIES` (default 1)
- `AFFPLUS_WEB_SEARCH_TIMEOUT_MS` (default 60000)
Prior knobs unchanged: `AFFPLUS_WEB_SEARCH_FALLBACK`, `AFFPLUS_WEB_MAX_SEARCHES`
(default 40), `AFFPLUS_WEB_SEARCH_MAX_USES`, `AFFPLUS_WEB_PAGES_PER_COUNTRY`,
`AFFPLUS_ALLOW_BETTING`, `AFFPLUS_DEFAULT_VERTICAL`, plus device/timeout knobs.

## Still your call, not a code fix
- Search budget (default 40) is a deliberate cost dial. Because the preview link
  is JS-bound, most offers resolve via the paid search, so 40 caps yield per job.
  Raise it and accept the cost, or vertical-seed the listing to cut volume.
- Verify on the first real run: that geos binds for Desktop, and that the detail
  extractors pull real values. Both now warn loudly if they fail.
- Ship script still needs this app's typecheck / build / mirror commands and a
  confirmation of which app this tree is. Not guessed.
